<?php

$con=mysqli_connect("localhost","root","","rob_store");

?>